const allowedId = 5763184393;

module.exports = {
  command: ["proses"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const parts = rawText?.split(/\s+/);
    if (!parts || parts.length < 2) {
      return client.sendMessage(message.chatId, {
        message: "❌ 注文内容を入力してください.\n\n例: Addplansプロセス",
        parseMode: "html",
        replyTo: message.id
      });
    }

    parts.shift(); // hapus kata 'proses'
    const deskripsi = parts.join(" ");

    const now = new Date();
    const hari = now.toLocaleDateString("id-ID", { weekday: "long" });
    const tanggal = now.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

    const caption = `<blockquote>
⚙️ <b>Pesanan Anda sedang diproses</b>
────────────────────────
📦 <b>注文:</b> <i>${deskripsi}</i>
📆 <b>日付:</b> ${tanggal}
📅 <b>日:</b> ${hari}
────────────────────────
しばらくお待ちください。プランを処理中です。.
</blockquote>`;

    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/7otu4k.jpg",
      caption,
      parseMode: "html",
      replyTo: message.id
    });
  }
};