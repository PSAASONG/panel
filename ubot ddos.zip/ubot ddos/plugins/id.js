 /*  
 */
const allowedId = 5763184393; // Ganti jika perlu

module.exports = {
command: ["id", "Id", "ID"],
run: async ({ client, message, reply }) => {
if (parseInt(message.senderId) !== allowedId) return;

let targetId;  

// Cek reply  
if (message.replyTo?.senderId) {  
  targetId = message.replyTo.senderId;  
}  

// Cek tag username  
else if (message.message) {  
  const mention = message.message.match(/@([a-zA-Z0-9_]+)/);  
  if (mention) {  
    try {  
      const user = await client.getEntity(mention[1]);  
      targetId = user.id;  
    } catch (e) {  
      return reply(`❌ ユーザー名が見つかりません.\n\nContoh:\n• タグID @MrMySutratorTeam`);  
    }  
  }  
}  

// Kalau tidak reply dan tidak tag  
if (!targetId) {  
  return reply(`❌ タグを使用してIDを確認する.\n\nContoh:\n• タグID @MrMySutratorTeam`);  
}  

try {  
  const user = await client.getEntity(targetId);  

  const info = `

🆔 ID: ${user.id}
👤 名前: ${user.firstName || ""} ${user.lastName || ""}
🔰 ユーザー名: ${user.username ? "@" + user.username : "-"}
`;

return reply(info, { parseMode: "html" });  
} catch (err) {  
  console.error("ID Error:", err);  
  return reply(`❌ Gagal mengambil data user.`);  
}

}
};