const allowedId = 5763184393;

module.exports = {
  command: ["reportch"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const abuseBot = "abusetelegram_bot";
    let pesan = message.message?.split(" ").slice(1).join(" ").trim();

    // Jika reply pesan, ambil isi pesan target
    if (message.replyToMsgId) {
      const replied = await client.getMessages(message.peerId, { ids: [message.replyToMsgId] });
      if (replied.length > 0) {
        const target = replied[0];
        pesan = `🚨 虐待報告:\n\n${target.message || "[メッセージを読むことができません]"}`;
      }
    }

    if (!pesan) {
      return client.sendMessage(message.peerId, {
        message: `❌ 記入してくださいまたはこの返信メッセージに記入してください.\n\n例:\n<code>UUITE法に違反しているとしてこのチャンネルを報告してください</code>`,
        parseMode: "html",
        replyTo: message.id
      });
    }

    try {
      await client.sendMessage(abuseBot, { message: pesan });
      return client.sendMessage(message.peerId, {
        message: `<blockquote>
✅ <b>レポートは正常に送信されました</b> @abusetelegram_bot
📝 <i>${pesan.length > 300 ? "メッセージが長すぎます." : メッセージ}</i>
</blockquote>`,
        parseMode: "html",
        replyTo: message.id
      });
    } catch (error) {
      console.error(error);
      return client.sendMessage(message.peerId, {
        message: "❌ レポートの送信に失敗しました @abusetelegram_bot. ブロックされたり拒否されたりしている可能性があります.",
        replyTo: message.id
      });
    }
  }
};