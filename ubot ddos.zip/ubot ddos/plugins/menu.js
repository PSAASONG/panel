 /*  
 */
 
const os = require("os");
const { formatSize } = require("../utils/fungsion");
const { performance } = require("perf_hooks");

const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);

function formatRuntime(ms) {
  let seconds = Math.floor(ms / 1000) % 60;
  let minutes = Math.floor(ms / (1000 * 60)) % 60;
  let hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  let days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

let botStartTime = performance.now();

// ID kamu
const allowedId = 8084582143;

module.exports = {
  command: ["menu"],
  run: async ({ client, message, reply }) => {
    if (parseInt(message.senderId) !== allowedId) return;

    const user = await client.getEntity(message.senderId);
    const username = user.username ? `@${user.username}` : "";
    const fullName = user.firstName + (user.lastName ? ` ${user.lastName}` : "");
    const mention = username || fullName;
    const userId = user.id;
    const runtime = formatRuntime(performance.now() - botStartTime);

    const caption = `<blockquote>
(☠️)
こんにちは、Ubot Pszyaです。AcilのDDoS対策をお手伝いします。
──────────────────────────
▢ Username: ${mention}
▢ Language : JavaScript 
▢ Runtime: ${runtime}
▢ Platform : Telegram
▢ ID Telegram: ${userId}

͜(!)𝐀͢𝐋͡𝐋 ⍣ 𝐌͢𝐄͡𝐍͜𝐔
▢ id
▢ trackip
▢ done
▢ proses
▢ ping
▢ reportch
▢ methods
</blockquote>`;

    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/3hlu9p.jpg",
      caption: caption,
      parseMode: "html",
      replyTo: message.id,
    });
  },
};