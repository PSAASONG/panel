const allowedId = 8084582143;

module.exports = {
  command: ["done"],
  run: async ({ client, message }) => {
    const senderId = parseInt(message.sender?.userId || message.senderId?.userId || message.senderId);
    if (senderId !== allowedId) return;

    const rawText = message.message?.trim();
    const parts = rawText?.split(/\s+/);

    if (!parts || parts.length < 3) {
      return client.sendMessage(message.peerId, {
        message: "❌ Masukkan deskripsi pesanan dan total harga.\n\nContoh: <code>done install panel 15k</code>",
        parseMode: "html",
        replyTo: message.id
      });
    }

    parts.shift(); // hapus 'done'
    const total = parts.pop(); // ambil harga
    const deskripsi = parts.join(" "); // sisanya jadi deskripsi

    const now = new Date();
    const hari = now.toLocaleDateString("id-ID", { weekday: "long" });
    const tanggal = now.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

    const caption = `<blockquote>
💕 <b>ご購入ありがとうございます</b>
────────────────────────
📦 <b>ご注文:</b> <i>${deskripsi}</i>
💰 <b>合計:</b> <code>${total}</code>
📆 <b>日付:</b> ${tanggal}
📅 <b>日:</b> ${hari}
────────────────────────
</blockquote>`;

    await client.sendFile(message.chatId, {
      file: "https://files.catbox.moe/7otu4k.jpg",
      caption: caption,
      parseMode: "html",
      replyTo: message.id,
    });
  }
};