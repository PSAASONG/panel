module.exports = {
    apiId: "37454313",
    apiHash: "50949094f098e304ceef6d71cc349afd",
    sessionFile: "session.json"
};
